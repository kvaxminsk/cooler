<?php
/**
 * Created by JetBrains PhpStorm.
 * User: vkorolyov
 * Date: 8/14/13
 * Time: 9:39 PM
 * To change this template use File | Settings | File Templates.
 */

   function ValidateEmail($email)
   {
       $pattern = '/^([0-9a-z]([-.\w]*[0-9a-z])*@(([0-9a-z])+([-\w]*[0-9a-z])*\.)+[a-z]{2,6})$/i';
       return preg_match($pattern, $email);
   }
   if($_SERVER['REQUEST_METHOD'] == 'POST')
   {
       $mailto = 'remont.cooler.by@gmail.com';
       $mailfrom = 'vopros@cooler.by';
       $subject = 'Website form';
       $message = 'Values submitted from web site form:';
       $success_url = 'http://remont.cooler.by/';
       $error_url = 'http://remont.cooler.by/';
       $error = '';
       $eol = "\n";
       $max_filesize = isset($_POST['filesize']) ? $_POST['filesize'] * 1024 : 1024000;
       $boundary = md5(uniqid(time()));

       $header  = 'From: '.$mailfrom.$eol;
       $header .= 'Reply-To: '.$mailfrom.$eol;
       $header .= 'MIME-Version: 1.0'.$eol;
       $header .= 'Content-Type: multipart/mixed; boundary="'.$boundary.'"'.$eol;
       $header .= 'X-Mailer: PHP v'.phpversion().$eol;
       if (!ValidateEmail($mailfrom))
       {
           $error .= "The specified email address is invalid!\n<br>";
       }
       if (!empty($error))
       {
           $errorcode = file_get_contents($error_url);
           $replace = "##error##";
           $errorcode = str_replace($replace, $error, $errorcode);
           echo $errorcode;
           exit;
       }
       $internalfields = array ("submit", "reset", "send", "captcha_code");
       $message .= $eol;
       $message .= "IP Address : ";
       $message .= $_SERVER['REMOTE_ADDR'];
       $message .= $eol;
       foreach ($_POST as $key => $value)
       {
           if (!in_array(strtolower($key), $internalfields))
           {
               if (!is_array($value))
               {
                   $message .= ucwords(str_replace("_", " ", $key)) . " : " . $value . $eol;
               }
               else
               {
                   $message .= ucwords(str_replace("_", " ", $key)) . " : " . implode(",", $value) . $eol;
               }
           }
       }
       $body  = 'This is a multi-part message in MIME format.'.$eol.$eol;
       $body .= '--'.$boundary.$eol;
       $body .= 'Content-Type: text/plain; charset=UTF-8'.$eol;
       $body .= 'Content-Transfer-Encoding: 8bit'.$eol;
       $body .= $eol.stripslashes($message).$eol;
       if (!empty($_FILES))
       {
           foreach ($_FILES as $key => $value)
           {
               if ($_FILES[$key]['error'] == 0 && $_FILES[$key]['size'] <= $max_filesize)
               {
                   $body .= '--'.$boundary.$eol;
                   $body .= 'Content-Type: '.$_FILES[$key]['type'].'; name='.$_FILES[$key]['name'].$eol;
                   $body .= 'Content-Transfer-Encoding: base64'.$eol;
                   $body .= 'Content-Disposition: attachment; filename='.$_FILES[$key]['name'].$eol;
                   $body .= $eol.chunk_split(base64_encode(file_get_contents($_FILES[$key]['tmp_name']))).$eol;
               }
           }
       }
       $body .= '--'.$boundary.'--'.$eol;
       mail($mailto, $subject, $body, $header);
       //header('Location: '.$success_url);
       //exit;
   }
?>