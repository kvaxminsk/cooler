jQuery.noConflict();
(function($) { 
  $(function() {

//	$('.calc tr td input.radio').first().attr('checked', true).parent('td').find('label').css("visibility","visible");
//	UpdateVal ();
	
	$('.calc tr td input.radio').click (function ff2(e){
		if (this.checked){
			$(this).prop('checked', false);
			$(this).parent('td').find('label').css("visibility","visible");
		}else{
			$(this).prop('checked', true);
			$(this).parent('td').find('label').css("visibility","hidden");
		}
		if ($(this).attr('type')=='radio'){
			var name_of_group = $(this).attr('name');
			$('input[name="'+ name_of_group +'"]').not($(this)).parent('td').find('label').css("visibility","hidden");
		}
		UpdateVal();
	});
	
	$('.r_td').click(function ff1(e)
			{
			var button = $(this).find('input.radio');
			if (button.prop('checked')==true){
				if (button.attr('type')=='radio'){
				}else{
					button.prop('checked', false);
					button.parent('td').find('label').css("visibility","hidden");
					}
			}else{
				button.prop('checked', true);
				button.parent('td').find('label').css("visibility","visible");
			}
			if (button.attr('type')=='radio'){
				var name_of_group = button.attr('name');
				$('input[name="'+ name_of_group +'"]').not(button).parent('td').find('label').css("visibility","hidden");
			}
			UpdateVal();
		});

	$('.clear_list').click(function(){
			$('input.radio').each(function() {
				$(this).attr('checked', false);
				$(this).parent('td').find('label').css("visibility","hidden");
				UpdateVal ();
			});
	});
		
	function UpdateVal () {
		var totalprice=0;
		var JSONarr= {};
		var i =0;
		$('input.radio').each(function() {
			if (this.checked)
					{
							JSONarr[i]={};
							totalprice += parseFloat($(this).parent('td').find('label span').html());
							JSONarr[i]['name']= $(this).parents('tr').find('th').html();
							JSONarr[i]['price']= $(this).parent('td').find('label span').html();
							i++;
					}
			$('#summ_num').html(totalprice.toFixed(3));
		});
		JSONarr['total'] = totalprice.toFixed(2);
		$('#order_field').val(JSON.stringify(JSONarr, null, 2));
	}
	
  });
})(jQuery);

