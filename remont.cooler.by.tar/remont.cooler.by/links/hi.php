<?php
$m="http://remont.cooler.by";
if ( isset($_GET['redirect']) ) {
$location = $_GET['redirect'];
header("Location: $location");
exit;
}
else {
header("Location: $m");
}
?>